#ifndef S_H_INCLUDED
#define S_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>

struct Stack* createStack();
void push(struct Stack *s, int number);
void pop(struct Stack *s);
int issEmpty(struct Stack *s);
int peek(struct Stack *s);
void traverse_List(struct Stack *s);


struct SNode
{
    int data;
    struct SNode *nextR;
};

struct Stack
{
    struct SNode *top;
};


struct Stack* createStack()
{
	struct Stack* s;
	s = (struct Stack*)malloc(sizeof(struct Stack));
	s->top = NULL;

	return s;
}

void push(struct Stack *s, int number)
{

    struct SNode *temp;
    temp = (struct SNode*)malloc(sizeof(struct SNode));

    (*temp).data = number;  // temp->data  = number;
    (*temp).nextR = s->top;   // temp->nextR = top;
    s->top = temp;
};


void pop(struct Stack *s)
{
    if(!issEmpty(s))
    {
        struct SNode *temp;

        temp = s->top;
        s->top = s->top->nextR;
        free(temp);
    }
};

int issEmpty(struct Stack *s)
{
    if(s->top == NULL)
    {
        return 1;
    }
    return 0;
}

void traverse_List(struct Stack *s)
{
    struct SNode *temp=s->top;

    while(temp != NULL)
    {
        printf("%d ", temp->data);

        temp = temp->nextR;
    }
    printf("\n");
}



int peek(struct Stack *s)
{
    if(!issEmpty(s))
    {
        return s->top->data;
    }
    else
    {
        exit(1);
    }
}


#endif // S_H_INCLUDED
