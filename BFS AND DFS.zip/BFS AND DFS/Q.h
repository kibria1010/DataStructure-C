#ifndef Q_H_INCLUDED
#define Q_H_INCLUDED

// A C program to demonstrate linked list based implementation of queue
#include <stdio.h>
#include <stdlib.h>

struct Queue* createQueue();
void enQueue(struct Queue * q, int num);
int deQueue(struct Queue* q);
int isEmpty(struct Queue *q);

// A linked list (LL) node to store a queue entry
struct QNode {
	int data;
	struct QNode* next;
};

// The queue, front stores the front node of LL and rear stores the last node of LL
struct Queue {
	struct QNode *f, *r;
};

// A utility function to create an empty queue
struct Queue* createQueue()
{
	struct Queue* q;
	q = (struct Queue*)malloc(sizeof(struct Queue));

	q->f = q->r = NULL;

	return q;
}

// The function to add a key k to q
void enQueue(struct Queue * q, int num)
{
	// Create a new LL node
	struct QNode* temp;
    temp = (struct QNode*)malloc(sizeof(struct QNode));
	temp->data = num;
	temp->next = NULL;

	// If queue is empty, then new node is front and rear both
	if (q->r == NULL) {
		q->f = q->r = temp;
		return;
	}

	// Add the new node at the end of queue and change rear
	q->r->next = temp;
	q->r = temp;
}

// Function to remove a key from given queue q
int deQueue(struct Queue* q)
{
	// If queue is empty, return NULL.
	if (q->f == NULL)
		return -1;

	// Store previous front and move front one node ahead
	struct QNode* temp = q->f;

	q->f = q->f->next;

	// If front becomes NULL, then change rear also as NULL
	if (q->f == NULL)
		q->r = NULL;

	return temp->data;
}

int isEmpty(struct Queue *q)
{
    if (q->f == NULL)
    {
        return 1;
    }
    return 0;
}

/*
// Driver Program to test anove functions
int main()
{
	struct Queue* q = createQueue();
	enQueue(q, 10);
	int data = deQueue(q);
	printf("%d ", data);
	enQueue(q, 20);
	 data = deQueue(q);
	printf("%d ", data);
	deQueue(q);

	return 0;
}
*/




#endif // Q_H_INCLUDED
