#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Q.h"
#include "S.h"

#include<stdio.h>
#include<stdlib.h>

struct G* createG(struct G *g, int numOfVartex);
void addEdge(struct G *g, int sV, int dV);
void printfG(struct G *g);

void bredthFirstSearch(struct G *g, int source);
void depthFirstSearch(struct G *g, int source);

void DFS(struct G *g, int source);
void dfsUtil(struct G *g, int *visited, int source);


struct ALN
{
    int dV;
    struct ALN *next;
};

struct AL
{
    struct ALN *head;
};

struct G
{
    int numOfV;
    struct AL *adjA;
};

int main()
{
    struct G *g;
    int choice, numOfV, sV, dV, source;

    while(1)
    {
        printf("###########################################");
        printf("\n1. Create G\n2. Add Edge\n3. Read G\n4. Delete Edge\n5. Exit\n6. BFS\n7. DFS");
        printf("\nEnter a choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                printf("Enter numer of vetices: ");
                scanf("%d", &numOfV);
                g = createG(g, numOfV);
                break;
            case 2:
                printf("Enter source and destination: ");
                scanf("%d", &sV);
                scanf("%d", &dV);
                addEdge(g, sV, dV);
                break;
            case 3:
                printfG(g);
                break;
            case 4:
                //deleteEdge();
                break;
            case 5:
                exit(1);
                break;
            case 6:
                printf("Enter the source from where BFS will start: ");
                scanf("%d", &source);
                bredthFirstSearch(g, source);   // প্রথম প্রস্থ অনুসন্ধান
                break;
            case 7:
            printf("Enter the source from where DFS will start: ");
            scanf("%d", &source);
            depthFirstSearch(g, source);   // প্রথম প্রস্থ অনুসন্ধান
                break;
            case 8:
                printf("Enter the source from where DFS will start: ");
                scanf("%d", &source);
                DFS(g, source);
                break;
            default:
                printf("Enter the right choice..!");
        }
    }
    return 0;
}

struct G* createG(struct G *g, int numOfV)
{
    g = (struct G*)malloc(sizeof(struct G));
    g->numOfV = numOfV;

    g->adjA = (struct AL*)malloc(numOfV*sizeof(struct AL));

    for(int i=0; i<g->numOfV; i++)
    {
        g->adjA[i].head = NULL;
    }

    printf("A G has been created with a AL for %d vertices.\n", numOfV);
    return g;
}


void addEdge(struct G *g, int sV, int dV)
{
    struct ALN *node1;
    node1 = (struct ALN*)malloc(sizeof(struct ALN));

    //adjA[sV] -> node for dV
    node1->dV = dV;
    node1->next = g->adjA[sV].head;
    g->adjA[sV].head = node1;
}

void printfG(struct G *g)
{
    for(int i=0; i<g->numOfV; i++)
    {
        struct ALN *temp = g->adjA[i].head;

        if(temp){ printf("\nAdjacency List of Vertex %d:\n", i); }
        while(temp != NULL)
        {
            printf("%d - %d ",i, temp->dV);
            temp = temp->next;
        }
    }
    printf("\n");
}


void bredthFirstSearch(struct G *g, int source)
{
    int *visited, *distance, currentSource=source;
    visited = (int*)malloc(g->numOfV * sizeof(int));
    distance = (int*)malloc(g->numOfV * sizeof(int));

    for(int i=0; i<g->numOfV; i++)
    {
        visited[i] = 0;
        distance[i] = INFINITY;
    }

    struct Queue *Q = createQueue();
    enQueue(Q, currentSource);
    distance[currentSource] = 0;

    while(!isEmpty(Q))
    {
        currentSource = deQueue(Q);
        if(visited[currentSource] == 0)
        {
            visited[currentSource] = 1;    // because of not printing circle.
            printf("%d ", currentSource);
            printf("\ndistance from %d to %d is: %d\n",source, currentSource, distance[currentSource]);
        }

        struct ALN *temp = g->adjA[currentSource].head;
        while(temp!=NULL)
        {
            if(visited[temp->dV] == 0)
            {
                enQueue(Q, temp->dV);
                distance[temp->dV] = distance[currentSource]+1;
            }
            temp = temp->next;
        }
    }


}


/*Input: n = 4, e = 6
0 -> 1, 0 -> 2, 1 -> 2, 2 -> 0, 2 -> 3, 3 -> 3
Output: DFS from vertex 1 : 1 2 0 3
*/
void depthFirstSearch(struct G *g, int source)
{
    int *visited;
    visited = (int*)malloc(g->numOfV * sizeof(int));

    for(int i=0; i<g->numOfV; i++)
    {
        visited[i] = 0;
    }

    struct Stack *S = createStack();
    push(S, source);

    while(!isEmpty(S))
    {
        source = peek(S);
        pop(S);
        if(visited[source] == 0)         //because of not printing circle.
        {
            printf("%d ", source);
            visited[source] = 1;
        }

        struct ALN *temp = g->adjA[source].head;
        while(temp!=NULL)
        {
            if(visited[temp->dV] == 0)
            {
                push(S, temp->dV);
            }
            temp = temp->next;
        }
    }
}

void DFS(struct G *g, int source)
{
    int *visited;
    visited = (int*)malloc(g->numOfV * sizeof(int));

    for(int i=0; i<g->numOfV; i++)
    {
        visited[i] = 0;
    }
    dfsUtil(g, visited, source);
}

void dfsUtil(struct G *g, int *visited, int source)
{
    printf("%d ", source);
    visited[source] = 1;

    struct ALN *temp = g->adjA[source].head;
    while(temp!=NULL)
    {
        if(visited[temp->dV] == 0)
        {
            dfsUtil(g, visited, temp->dV);
        }
        temp = temp->next;
    }
}



